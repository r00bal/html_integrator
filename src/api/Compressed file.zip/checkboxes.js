import { regFor, s } from "./regExp.js";

export const checkboxes = [
  {
    name: "Add HR & LHR favicon",
    value: "LHRfavicon",
    todo: "ADD",
    error: "favicon error",
    location: "<head>",
    default: "HR",
    code: s.faviconHR
  },

  {
    name: "Add footerMay",
    value: "footerMay",
    todo: "REPLACE",
    error: "footerMay error",
    location: regFor.divFooter,
    default: "ALL",
    code: s.footerMay
  },
  {
    name: "Remove 'Table-layout:fixed'",
    value: "removeTableLayoutFixed",
    todo: "REPLACE",
    error: "removeTableLayoutFixed error",
    location: regFor.tableLayout,
    default: "no",
    code: s.empty
  },
  {
    name: "Add gmail fix",
    value: "gmailFix",
    todo: "ADD",
    error: "gmailFix error",
    location: "</style>",
    default: "ALL",
    code: s.gmailFix
  },
  {
    name: "Ad WR",
    value: "adWRtoImgs",
    todo: "REPLACE",
    error: "adWRtoImgs error",
    location: "</style>",
    default: "ALL",
    code: s.imgUrl
  }
];
